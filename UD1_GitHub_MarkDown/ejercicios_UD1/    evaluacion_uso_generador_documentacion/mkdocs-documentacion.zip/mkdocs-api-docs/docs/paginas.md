# Documentación de Páginas HTML

Este sitio web está compuesto por varias páginas HTML estáticas. A continuación, se describen las principales páginas, su contenido y su función dentro del sitio.

---

## Página: Usuarios

**Ruta**: `/usuarios.html`  
**Descripción**: Muestra una lista de usuarios registrados con sus nombres y correos electrónicos.

**Contenido principal**:

- Tabla con información de usuarios
- Botones para editar o eliminar usuarios

**Captura de pantalla**:

![Vista de usuarios](img/usuarios.png)

---

## Página: Inicio

**Ruta**: `/index.html`  
**Descripción**: Página principal del sitio. Presenta una bienvenida, enlaces a otras secciones y una breve introducción.

**Contenido principal**:

- Logo y menú de navegación
- Enlace a la página de usuarios
- Información básica

---

## Página: Contacto

**Ruta**: `/contacto.html`  
**Descripción**: Permite a los visitantes enviar mensajes al administrador del sitio.

**Contenido principal**:

- Formulario con campos: nombre, correo, mensaje
- Botón de enviar

---

## Navegación del sitio

Todas las páginas incluyen un menú de navegación superior con enlaces a:

- Inicio
- Usuarios
- Contacto
